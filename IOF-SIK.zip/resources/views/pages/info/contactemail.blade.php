
<p><strong>New contact message</strong></p>
<p>Name: {{ $name }}</p>
<p>Email: {{ $email }}</p>
<p>{{ $comment }}</p>