<div class="ajax-inline-page" data-url="{{ $url }}" data-props="{{ json_encode($props) }}">
	
</div>