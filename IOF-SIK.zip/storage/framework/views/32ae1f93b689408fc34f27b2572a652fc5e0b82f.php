<footer class="footer border-top">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-4">
				<div class="copyright">All Rights Reserved | &copy; <?php echo e(config("app.name")); ?> - <?php echo e(date('Y')); ?></div>
			</div>
			<div class="col">
				<div class="footer-links text-right">
					<a href="<?php echo e(url('info/about')); ?>">About us</a> | 
					<a href="<?php echo e(url('info/faq')); ?>">Help and FAQ</a> |
					<a href="<?php echo e(url('info/contact')); ?>">Contact us</a>  |
					<a href="<?php echo e(url('info/privacypolicy')); ?>">Privacy Policy</a> |
					<a href="<?php echo e(url('info/termsandconditions')); ?>">Terms and Conditions</a>
				</div>
			</div>
			
		</div>
	</div>
</footer><?php /**PATH D:\xampp\htdocs\IOF-SIK\resources\views/appfooter.blade.php ENDPATH**/ ?>