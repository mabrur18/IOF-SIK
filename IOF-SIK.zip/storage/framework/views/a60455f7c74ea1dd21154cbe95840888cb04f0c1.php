
	<div class="">
		<?php 
			$chartdata = $comp_model->barchart_newchart1();
		?>
		<div class="p-3">
			<div class=" font-weight-bold h4">New Chart 1</div>
			<small class="text-muted"></small>
		</div>
		<canvas id="barchart_newchart1"></canvas>
		<script>
			$(function (){
			var chartData = {
				labels: <?php echo json_encode($chartdata['labels']); ?>,
				datasets: <?php echo json_encode($chartdata['datasets']); ?>
			}
			var ctx = document.getElementById('barchart_newchart1');
			var chart = new Chart(ctx, {
				type:'bar',
				data: chartData,
				
				options: {
					scaleStartValue: 0,
					responsive: true,
					scales: {
						xAxes: [{
							ticks:{display: true},
							gridLines:{display: true},
							categoryPercentage: 1.0,
							barPercentage: 0.8,
							scaleLabel: {
								display: true,
								labelString: ""
							},
						}],
						yAxes: [{
							ticks: {
								beginAtZero: true,
								display: true
							},
							scaleLabel: {
							display: true,
							labelString: ""
						}
						}]
					},
				}
,
			})});
		</script>
	</div>
<?php /**PATH D:\xampp\htdocs\IOF-SIK\resources\views/pages/home-new-chart-1.blade.php ENDPATH**/ ?>