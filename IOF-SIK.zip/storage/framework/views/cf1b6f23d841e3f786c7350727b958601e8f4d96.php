
<?php $__env->startSection('content'); ?>
<div class="container my-4">
	<h4>About</h4>
	<hr />
	<div>
		<p>Put page content here.</p>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\IOF-SIK\resources\views/pages/info/about.blade.php ENDPATH**/ ?>