<div class="ajax-inline-page" data-url="<?php echo e($url); ?>" data-props="<?php echo e(json_encode($props)); ?>">
	
</div><?php /**PATH D:\xampp\htdocs\IOF-SIK\resources\views/components/sub-page.blade.php ENDPATH**/ ?>